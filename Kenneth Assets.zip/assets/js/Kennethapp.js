// message in the console
console.log("Hi there, welcome to the JavaScript console!");

// initialize the application
var app = new Object();



  app.shakePokeball = function shakePokeball() {
    // code BELOW this line for challenge #1 -->
    // var shake = document.getElementById("button-primary");
    //  element.classList.add("shake");
    // alert("test");
    var pokeballClass = document.getElementById('pokeball');
    pokeball.className = 'shake';
    
  }; // <-- code ABOVE this line for challenge #1
  
  app.setName = function setName() {
    // code BELOW this line for challenge #2 -->
    var message = prompt("Please enter your Name!");
    document.getElementById('first-name').innerHTML = message; 
    // document.getElementById('first-name').style.textAlign = "center";   not working, only padding " 0 0 0 20-30px;"
    console.log("Your name is: ", message);

  }; // <-- code ABOVE this line for challenge #2
  
  app.setWebsite = function setWebsite() {
    // code BELOW this line for challenge #3 & bonus -->
    // Bonus
    var favWebsite = prompt("Please enter your Favorite Website: ")
    document.getElementById('favorite-website').innerHTML = "<a href=https://" + favWebsite + ">" + favWebsite + "</a>";
    console.log("Your favorite website is: ",favWebsite);
  }; // <-- code ABOVE this line for challenge #3 & bonus

  

  
  

